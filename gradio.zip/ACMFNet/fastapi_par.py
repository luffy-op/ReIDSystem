import argparse, os.path as path
from re import L
import torch, torch.nn.functional as F
from tqdm import tqdm
from PIL import Image
from torchvision import transforms
from vit.build import build_model
from vit.swin_config import get_config
from config_args import get_args

from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn


args = get_args(argparse.ArgumentParser())
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 定义请求数据结构
class ImageRequest(BaseModel):
    image_path: str  # 图像路径    

class PAR:
    ATTRIBUTES = [
        "Hat", "Glasses", 
        "ShortSleeve", "LongSleeve", "UpperStride", "UpperLogo", "UpperPlaid", "UpperSplice", 
        "LowerStripe", "LowerPattern", "LongCoat", "Trousers", "Shorts", "Skirt&Dress", 
        "boots", 
        "HandBag", "ShoulderBag", "Backpack", "HoldObjectsInFront", 
        "AgeOver60", "Age18-60", "AgeLess18", 
        "Female", 
        "Front", "Side", "Back"
    ]

    def __init__(self, args):
        self.config = get_config(args)
        self.device = device
        self.args = args

        # 检查是否有可用的 GPU
        self.device = device

        # 构建模型并移动到设备
        self.model = build_model(self.config, args.num_labels, args.maskratio).to(self.device)

        # 获取模型的输入尺寸
        img_size = self.config.DATA.IMG_SIZE

        # 动态设置 transforms.Resize 的目标尺寸
        self.transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.CenterCrop(img_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        # 如果指定了保存的模型权重，加载权重
        if args.saved_model_name:
            self.model = self.load_saved_model(args.saved_model_name, self.model)

    def infer(self, img_path, desc="Inference"):
        self.model.eval()  # 确保模型处于评估模式

        # 加载并预处理图片
        image = Image.open(img_path).convert('RGB')
        image = self.transform(image).unsqueeze(0).to(self.device)  # 添加 batch 维度并移动到设备

        with torch.no_grad():
            pred, _, _ = self.model(image, tid=0)  # 模型推理
            
        pred = F.sigmoid(pred)

        # 确定属性是否存在
        threshold = 0.5
        binary_result = (pred >= threshold).tolist()

        # 提取存在的属性
        present_attributes = [attr for attr, exists in zip(self.ATTRIBUTES, binary_result[0]) if exists]

        # 将属性映射到概率
        predictions = {attr: f'{prob.item():.2f}' for attr, prob in zip(self.ATTRIBUTES, pred[0])}

        return present_attributes, predictions

    def load_saved_model(self, saved_model_name, model):
        checkpoint = torch.load(saved_model_name, map_location=self.device)  # 确保权重加载到正确的设备
        model.load_state_dict(checkpoint)
        return model

    def run_epoch(self, img_paths, desc="Running Epoch"):
        self.model.eval()  # Ensure the model is in evaluation mode

        # Pre-allocate full prediction tensor
        all_predictions = torch.zeros(len(img_paths), self.args.num_labels).cpu()

        for idx, img_path in enumerate(tqdm(img_paths, mininterval=0.5, desc=desc, leave=False, ncols=50)):
            # Load and preprocess the image
            image = Image.open(img_path).convert('RGB')
            image = self.transform(image).unsqueeze(0)  # Add batch dimension

            with torch.no_grad():
                pred, _, _ = self.model(image.cuda(), tid=0)

            all_predictions[idx] = pred.data.cpu()

        return all_predictions
    
# 创建 FastAPI 应用
app = FastAPI()

# 加载模型
par_model = PAR(args)

# API 端点
@app.post("/predict_par")
async def predict_attributes(request: ImageRequest):
    try:
        # 确保请求中的 image_path 存在
        if not path.exists(request.image_path):
            return {"error": f"Image path {request.image_path} does not exist."}
        
        present_attributes, predictions = par_model.infer(request.image_path)
        return {"present_attributes": present_attributes, "predictions": predictions}
    except Exception as e:
        return {"error": str(e)}
    
# 启动 FastAPI 服务器
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5001)