import argparse
import datetime
import json
import os
import random
import time
import numpy as np
import ruamel_yaml as yaml
import torch
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.nn.functional as F
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

#allow_tf32
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
import torchvision as tv
import utils
from models.model_person_search import ALBEF
from models.tokenization_bert import BertTokenizer
from models.vit import interpolate_pos_embed

# 定义请求数据结构
class TextRequest(BaseModel):
    text: str  # 图像路径

class TIReID:
    def __init__(self):
        
        # self._load_config()
        parser = argparse.ArgumentParser()
        parser.add_argument('--config', default='./configs/PS_cuhk_pedes.yaml')
        parser.add_argument('--output_dir', default='output/cuhk-pedes')
        parser.add_argument('--checkpoint', default='')
        parser.add_argument('--resume', action='store_true')
        parser.add_argument('--eval_mAP', action='store_true', help='whether to evaluate mAP')
        parser.add_argument('--text_encoder', default='bert-base-uncased')
        parser.add_argument('--evaluate', action='store_true')
        parser.add_argument('--device', default='cuda')
        parser.add_argument('--seed', default=42, type=int)
        parser.add_argument('--world_size', default=1, type=int, help='number of distributed processes')
        parser.add_argument('--dist_url', default='env://', help='url used to set up distributed training')
        parser.add_argument('--distributed', default=True, type=bool)
        args = parser.parse_args()
        self.args = args
        self.config = yaml.load(open(args.config, 'r'), Loader=yaml.Loader)
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
        yaml.dump(self.config, open(os.path.join(args.output_dir, 'config.yaml'), 'w'))
        
        self.device = torch.device(args.device)
        self.tokenizer = BertTokenizer.from_pretrained(args.text_encoder)
        self.model = ALBEF(config=self.config, text_encoder=args.text_encoder, tokenizer=self.tokenizer).to(self.device)
        self.load_params(args.checkpoint)
        
    # def _load_config(self):
    #     """
    #     加载配置文件并冻结配置
    #     """
    #     parser = argparse.ArgumentParser()
    #     parser.add_argument('--config', default='./configs/PS_cuhk_pedes.yaml')
    #     parser.add_argument('--output_dir', default='output/cuhk-pedes')
    #     parser.add_argument('--checkpoint', default='')
    #     parser.add_argument('--resume', action='store_true')
    #     parser.add_argument('--eval_mAP', action='store_true', help='whether to evaluate mAP')
    #     parser.add_argument('--text_encoder', default='bert-base-uncased')
    #     parser.add_argument('--evaluate', action='store_true')
    #     parser.add_argument('--device', default='cuda')
    #     parser.add_argument('--seed', default=42, type=int)
    #     parser.add_argument('--world_size', default=1, type=int, help='number of distributed processes')
    #     parser.add_argument('--dist_url', default='env://', help='url used to set up distributed training')
    #     parser.add_argument('--distributed', default=True, type=bool)
    #     args = parser.parse_args()
    #     config = yaml.load(open(args.config, 'r'), Loader=yaml.Loader)
    #     Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    #     yaml.dump(config, open(os.path.join(args.output_dir, 'config.yaml'), 'w'))
    
    def load_params(self, checkpoint):
        checkpoint = torch.load(self.args.checkpoint, map_location='cpu')
        state_dict = checkpoint['model']
        # reshape positional embedding to accomodate for image resolution change
        pos_embed_reshaped = interpolate_pos_embed(state_dict['visual_encoder.pos_embed'], self.model.visual_encoder)
        state_dict['visual_encoder.pos_embed'] = pos_embed_reshaped
        m_pos_embed_reshaped = interpolate_pos_embed(state_dict['visual_encoder_m.pos_embed'],
                                                         self.model.visual_encoder_m)
        state_dict['visual_encoder_m.pos_embed'] = m_pos_embed_reshaped
        msg = self.model.load_state_dict(state_dict, strict=False)
        print('load checkpoint from %s' % self.args.checkpoint)
        print(msg)

    def infer(self, text):
        # evaluate
        self.model.eval()
        metric_logger = utils.MetricLogger(delimiter="  ")
        header = 'Evaluation:'
        print('Computing features for evaluation...')
        start_time = time.time()
        
        text_inputs_ids = [] # new version
        text_atts_new_version = []
        text_feats = []
        text_embeds = []
        text_atts = []
        
        text = [text]
        text_input = self.tokenizer(text, padding='max_length', truncation = True,  max_length=self.config["max_words"], return_tensors="pt").to(self.device)
        text_output = self.model.text_encoder.bert(text_input.input_ids, attention_mask=text_input.attention_mask, mode='text')
        text_feat = text_output.last_hidden_state
        text_embed = F.normalize(self.model.text_proj(text_feat[:, 0, :]))
        text_embeds.append(text_embed)
        text_embeds = torch.cat(text_embeds, dim=0) # 1 256

        # 从文件加载 image_embeds
        image_embeds = torch.load("output/image_embeds.pt")  # 从文件加载
        image_embeds = image_embeds.to(self.device)
        print('gallery 图像特征已从output/image_embeds.pt加载')
        
        # compute the feature similarity score for all image-text pairs
        sims_matrix = text_embeds @ image_embeds.t() # 1 3074

        # 从文件读取 data_loader.dataset.image
        with open("output/image_paths.txt", "r") as f:
            g_img_path = [line.strip() for line in f.readlines()]
        
        _, topk_idx = sims_matrix[0].topk(k=self.config['k_test'], dim=0)
        top10_idx = topk_idx[:10].cpu().numpy()
        top10_images = [g_img_path[idx] for idx in top10_idx]
        top10_imgpath = [os.path.join("/workspace/zl/A_datasets/CUHK-PEDES/imgs", filename) for filename in top10_images]
        return top10_imgpath


# 创建 FastAPI 应用
app = FastAPI()

# 加载模型
tireid_model = TIReID()

# API 端点
@app.post("/predict_tireid")
async def predict_tireid(request: TextRequest):
    """
    接收图片路径，返回前 10 张匹配图片的路径
    """
    try:
        predictions = tireid_model.infer(request.text)
        return {"predictions": predictions}
    except FileNotFoundError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"An unexpected error occurred: {str(e)}"}

# 启动 FastAPI 服务器
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5003)