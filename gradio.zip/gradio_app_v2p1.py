import gradio as gr
import requests
import json
import time  # 添加时间模块

# 读取 JSON 主题文件
# with open("themes/theme_schema%400.0.4.json", "r", encoding="utf-8") as f:
#     theme_dict = json.load(f)
# theme = gr.Theme.from_dict(theme_dict)

ATTRIBUTES = [
    "Hat", "Glasses", 
    "ShortSleeve", "LongSleeve", "UpperStride", "UpperLogo", "UpperPlaid", "UpperSplice", 
    "LowerStripe", "LowerPattern", "LongCoat", "Trousers", "Shorts", "Skirt&Dress", 
    "boots", 
    "HandBag", "ShoulderBag", "Backpack", "HoldObjectsInFront", 
    "AgeOver60", "Age18-60", "AgeLess18", 
    "Female", 
    "Front", "Side", "Back"
]

def par_pred(image_path):
    start_time = time.time()  # 记录开始时间
    
    response = requests.post("http://127.0.0.1:5001/predict_par", json={"image_path": image_path})
    
    if response.status_code == 200:
        elapsed_time = time.time() - start_time  # 计算花费时间
        
        present_attributes = response.json()["present_attributes"]
        predictions = response.json()["predictions"]
        
        # 过滤出存在的属性名
        present_attributes = [ATTRIBUTES[i] for i in range(len(ATTRIBUTES)) if ATTRIBUTES[i] in present_attributes]
        
        attr_region = []
        idxs = [2, 6, 6, 1, 4, 3, 1, 3]
        cout = 0
        for i in range(len(idxs)):
            attr_region.append([ATTRIBUTES[cout+j] for j in range(idxs[i]) if ATTRIBUTES[cout+j] in present_attributes])
            cout += idxs[i]
            
        return attr_region[0], attr_region[1], attr_region[2], attr_region[3], attr_region[4], attr_region[5], attr_region[6], attr_region[7], predictions, {"elapsed_time": f"{elapsed_time:.2f}秒"}
    else:
        return "Error"

def reid_pred(image_path):
    start_time = time.time()  # 记录开始时间
    
    response = requests.post("http://127.0.0.1:5002/predict_reid", json={"image_path": image_path})
    
    elapsed_time = time.time() - start_time  # 计算花费时间
    
    if response.status_code == 200:
        predictions = response.json()["predictions"]
        performance = {"elapsed_time": f"{elapsed_time:.2f}秒"}
        return predictions, performance
    else:
        return "Error", {"elapsed_time": "N/A"}

def tireid_pred(text):
    start_time = time.time()  # 记录开始时间
    
    response = requests.post("http://127.0.0.1:5003/predict_tireid", json={"text": text})
    
    elapsed_time = time.time() - start_time  # 计算花费时间
    
    if response.status_code == 200:
        if "predictions" in response.json() and "performance" in response.json():
            # 如果后端已经返回性能信息
            return response.json()["predictions"], response.json()["performance"]
        else:
            # 如果后端没有返回性能信息，使用前端计算的时间
            predictions = response.json()["predictions"]
            performance = {"elapsed_time": f"{elapsed_time:.2f}秒"}
            return predictions, performance
    else:
        return "Error", {"elapsed_time": "N/A"}

with gr.Blocks(css="styles.css") as demo:
    # 添加大标题
    gr.Markdown(
        "## 基于属性信息的行人重识别程序演示", 
        elem_id="main-title", 
    )
    
    with gr.Tab("行人属性识别"):
        gr.Markdown("# 🏃‍♂️ 行人属性识别")
        gr.Markdown("通过上传图像，系统将识别行人的属性。")
        with gr.Row():
            with gr.Column(scale=2):
                image_input = gr.Image(type="filepath", label="上传图像", elem_id="image-input")
                    
                 # 添加图像示例
                examples = f'./example_par'
                gr.Examples(
                    examples=examples,
                    inputs=image_input,
                    label="示例图像",
                    elem_id="examples-par",
                    examples_per_page=6
                )
                    
                submit_button = gr.Button("开始预测", variant="primary", elem_id="predict-button")
                with gr.Row():
                    # 添加性能指标显示
                    output_performance = gr.JSON(label="预测性能", elem_id="performance-reid")
                    
            with gr.Column(scale=3):
                with gr.Row():
                    output_checkbox_head = gr.CheckboxGroup(ATTRIBUTES[:2], label="头部区域", elem_id="attributes-output-head")
                with gr.Row():
                    output_checkbox_upper = gr.CheckboxGroup(ATTRIBUTES[2:8], label="上身区域", elem_id="attributes-output-upper")
                with gr.Row():
                    output_checkbox_lower = gr.CheckboxGroup(ATTRIBUTES[8:14], label="下身区域", elem_id="attributes-output-lower")
                with gr.Row():
                    output_checkbox_foot = gr.CheckboxGroup(ATTRIBUTES[14:15], label="脚部区域", elem_id="attributes-output-foot")
                with gr.Row():
                    output_checkbox_accessory = gr.CheckboxGroup(ATTRIBUTES[15:19], label="配件/包", elem_id="attributes-output-accessory")
                with gr.Row():
                    output_checkbox_age = gr.CheckboxGroup(ATTRIBUTES[19:22], label="年龄", elem_id="attributes-output-age")
                with gr.Row():
                    output_checkbox_gender = gr.CheckboxGroup(ATTRIBUTES[22:23], label="性别", elem_id="attributes-output-gender")
                with gr.Row():
                    output_checkbox_orientation = gr.CheckboxGroup(ATTRIBUTES[23:], label="身体朝向", elem_id="attributes-output-orientation")
                output_text = gr.JSON(label="属性概率", elem_id="probabilities-output")
        submit_button.click(
            fn=par_pred, 
            inputs=image_input, 
            outputs=[
                output_checkbox_head, 
                output_checkbox_upper, 
                output_checkbox_lower, 
                output_checkbox_foot, 
                output_checkbox_accessory, 
                output_checkbox_age, 
                output_checkbox_gender, 
                output_checkbox_orientation, 
                output_text,
                output_performance
            ]
        )

    with gr.Tab("属性辅助的行人重识别"):
        gr.Markdown("# 🏃‍♂️ 属性辅助的行人重识别")
        gr.Markdown("通过上传图像，系统将从图库查询相似的行人")
        with gr.Row():
            with gr.Column(scale=1):
                image_input = gr.Image(type="filepath", label="上传图像", elem_id="image-input-reid")
                
                # 添加图像示例
                examples = f'./example_reid'
                gr.Examples(
                    examples=examples,
                    inputs=image_input,
                    label="示例图像",
                    elem_id="examples-reid",
                    examples_per_page=5
                )
                submit_button = gr.Button("开始预测", variant="primary", elem_id="predict-button-reid")
            with gr.Column(scale=2):
                gallery = gr.Gallery(label="查询结果前十名", show_label=True, elem_id="gallery-reid", columns=[5], rows=[1], object_fit="contain", height="auto")
                # 添加性能指标显示
                performance_output = gr.JSON(label="预测性能", elem_id="performance-reid")
        
        # 更新点击事件，添加新的输出
        submit_button.click(fn=reid_pred, inputs=image_input, outputs=[gallery, performance_output])
    
    with gr.Tab("文本到图像的行人重识别"):
        # 标题
        gr.Markdown("# 🏃‍♂️ 文本到图像的行人重识别")
        gr.Markdown("通过输入文本描述，系统将从图库查询与文本匹配的行人")

        # 输入
        with gr.Row():
            text_input = gr.Textbox(label="输入文本", placeholder="请输入对行人的文本描述", elem_id="text-input")
        
        # 示例数据
        # "A woman wearing a black shirt, a light blue jean jacket, a pair of brown pants and a wrist watch.",
        # "This woman is wearing silver headphones and glasses wiht a dark shirt and jeans with shoes that have a big white heel and has a pink backpack slung over her right shoulder."
        examples = [
            "This person is wearing glasses and has a white collared dark shirt and dark pants with his bag over his right shoulder",
            "The man is riding a bicycle and he is wearing a black shirt with black shorts and white shoes",
            "The woman is wearing a purple and white patterned shirt with light blue jeans and a brown shoulder bag",
            "Male with black hair is wearing eyeglasses and a long sleeved shirt with dark denim pants and dark shoes"
        ]
        gr.Examples(
            examples=examples,
            inputs=text_input,
            label="示例行人描述",
            elem_id="examples-tireid"
        )

        # 分隔线
        gr.Markdown("---")

        # 事件绑定
        submit_button = gr.Button("开始预测", variant="primary", elem_id="predict-button-tireid")

        # 输出
        gallery = gr.Gallery(label="查询结果前十名", show_label=True, elem_id="gallery-tireid", columns=[5], rows=[1], object_fit="contain", height="auto")
        # 添加性能指标显示
        performance_output = gr.JSON(label="预测性能", elem_id="performance-tireid")

        # 更新点击事件，添加新的输出
        submit_button.click(fn=tireid_pred, inputs=text_input, outputs=[gallery, performance_output])

# 启动服务
demo.launch(server_name="0.0.0.0", server_port=80)

# with gr.Blocks(css=".gradio-container { font-family: Arial, sans-serif; }") as demo: