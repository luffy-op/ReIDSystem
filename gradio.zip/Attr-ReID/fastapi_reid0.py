"""
This code is modified from Hao Luo's repository.
Paper: Bag of Tricks and A Strong Baseline for Deep Person Re-identification
https://github.com/michuanhaohao/reid-strong-baseline
-------------------------------------------------------------------------------
Edited by Binh X. Nguyen and Binh D. Nguyen
Paper: Graph-based Person Signature for Person Re-Identifications
https://github.com/aioz-ai/CVPRW21_GPS
"""

import argparse
import os
import sys
from os import mkdir
import torch
from torch.backends import cudnn

sys.path.append('.')
from config import cfg
from data import make_data_loader
# from engine.inference import inference
from engine.inference_visual import inference
# from modeling import build_model
from utils.logger import setup_logger

from modeling import build_model_baseline, build_model_Conloss
from utils.reid_metric import R1_mAP, R1_mAP_reranking

def get_model_size(model):
    param_size = 0
    buffer_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
    for buffer in model.buffers():
        buffer_size += buffer.nelement() * buffer.element_size()
    size_all_mb = (param_size + buffer_size) / 1024**2
    return size_all_mb

class REID:
    
    def __init__(self, config_file, opts):
        self.config_file = config_file
        self.opts = opts
        self.num_gpus = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1
        self.output_dir = cfg.OUTPUT_DIR
        self.logger = setup_logger("reid_baseline", self.output_dir, 0)
        self.num_query = 0
        self.num_classes = 0
        self.model = None
        self.checkpoint = None
        
    def infer_top10(self, image_path):
        
        return

def main():
    parser = argparse.ArgumentParser(description="ReID Baseline Inference")
    parser.add_argument(
        "--config_file", default="", help="path to config file", type=str
    )
    parser.add_argument("opts", help="Modify config options using the command-line", default=None,
                        nargs=argparse.REMAINDER)

    args = parser.parse_args()

    num_gpus = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1

    if args.config_file != "":
        cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()

    output_dir = cfg.OUTPUT_DIR
    if output_dir and not os.path.exists(output_dir):
        mkdir(output_dir)

    logger = setup_logger("reid_baseline", output_dir, 0)
    logger.info("Using {} GPUS".format(num_gpus))
    logger.info(args)

    if args.config_file != "":
        logger.info("Loaded configuration file {}".format(args.config_file))
        with open(args.config_file, 'r') as cf:
            config_str = "\n" + cf.read()
            logger.info(config_str)
    logger.info("Running with config:\n{}".format(cfg))

    if cfg.MODEL.DEVICE == "cuda":
        os.environ['CUDA_VISIBLE_DEVICES'] = cfg.MODEL.DEVICE_ID
    cudnn.benchmark = True

    train_loader, val_loader, num_query, num_classes = make_data_loader(cfg)
    # print('num_classes: ', num_classes)
    # import sys
    # sys.exit()
    # model = build_model(cfg, num_classes)
    # model = build_model_Conloss(cfg, num_classes)
    model = build_model_baseline(cfg, num_classes)
    checkpoint = torch.load(cfg.TEST.WEIGHT)
    print(f'Model size: {get_model_size(model):.3f} MB')
    model.load_param(cfg.TEST.WEIGHT)
    # # model.load_state_dict(checkpoint['model_state_dict'])

    # inference(cfg, model, val_loader, num_query)
    R1_mAP_reranking(num_query, max_rank=50, feat_norm=cfg.TEST.FEAT_NORM)


if __name__ == '__main__':
    main()
