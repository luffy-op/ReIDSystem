import os
import argparse
import torch
from PIL import Image
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

from config import cfg
from utils.result_vis import Q_VIS
from data.datasets.dataset_loader import read_image
from data.transforms import build_transforms
from modeling import build_model_baseline

# 项目路径
PROJECT_PATH = os.path.dirname(__file__)

# 定义请求数据结构
class ImageRequest(BaseModel):
    image_path: str  # 图像路径

class PersonReID:
    def __init__(self, config_file="configs/sb_market1501_gps_softmax_triplet_center.yml"):
        """
        初始化行人重识别模型
        """
        # 加载配置文件
        self._load_config(config_file)

        # 构建数据预处理和模型
        self.transform = build_transforms(cfg, is_train=False)
        self.model = build_model_baseline(cfg, 751)
        self.model.load_param(cfg.TEST.WEIGHT)
        self.model.eval()  # 设置模型为评估模式

        # 初始化结果可视化工具
        self.num_query = 1
        self.q_vis = Q_VIS(self.num_query, max_rank=50, feat_norm=cfg.TEST.FEAT_NORM)

    def _load_config(self, config_file):
        """
        加载配置文件并冻结配置
        """
        parser = argparse.ArgumentParser(description="ReID Baseline Inference")
        parser.add_argument("--config_file", default=config_file, help="path to config file", type=str)
        parser.add_argument("opts", help="Modify config options using the command-line", default=None, nargs=argparse.REMAINDER)
        args = parser.parse_args([])  # 使用空参数列表以避免命令行冲突

        args.config_file = os.path.join(PROJECT_PATH, args.config_file)
        if args.config_file:
            cfg.merge_from_file(args.config_file)
        cfg.merge_from_list(args.opts)
        cfg.freeze()

    def infer(self, img_path):
        """
        对输入图片进行推理，返回前 50 张匹配图片的路径
        """
        # 检查图片路径是否存在
        if not os.path.exists(img_path):
            raise FileNotFoundError(f"Image path {img_path} does not exist.")

        # 读取并预处理图片
        img = read_image(img_path)  # PIL 图像
        img = self.transform(img).unsqueeze(0)  # 添加 batch 维度

        # 模型推理
        with torch.no_grad():
            feat = self.model(img)

        # 计算匹配结果
        result = self.q_vis.compute(feat)
        return result[0]  # 返回前 50 张匹配图片路径

# 创建 FastAPI 应用
app = FastAPI()

# 加载模型
reid_model = PersonReID()

# API 端点
@app.post("/predict_reid")
async def predict_reid(request: ImageRequest):
    """
    接收图片路径，返回前 50 张匹配图片的路径
    """
    try:
        predictions = reid_model.infer(request.image_path)
        return {"predictions": predictions}
    except FileNotFoundError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"An unexpected error occurred: {str(e)}"}

# 启动 FastAPI 服务器
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5002)