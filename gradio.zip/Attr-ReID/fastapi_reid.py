from torchvision.transforms.functional import to_pil_image

class REID:
    # ... 省略已有代码 ...

    def infer_top_k(self, img_path, k=10):
        """
        输入一张行人图片路径，输出模型识别到的前 k 张图片路径。
        """
        self.model.eval()  # 确保模型处于评估模式

        # 加载并预处理输入图片
        query_image = Image.open(img_path).convert('RGB')
        query_image = self.transform(query_image).unsqueeze(0).to(self.device)  # 添加 batch 维度并移动到设备

        # 获取数据集的验证集加载器
        _, val_loader, num_query, _ = make_data_loader(self.args)

        # 提取查询图片的特征
        with torch.no_grad():
            query_feature = self.model(query_image)

        # 提取验证集中所有图片的特征
        gallery_features = []
        gallery_paths = []
        for batch in val_loader:
            images, paths = batch['images'], batch['paths']  # 假设数据加载器返回图片和路径
            images = images.to(self.device)

            with torch.no_grad():
                features = self.model(images)
                gallery_features.append(features)
                gallery_paths.extend(paths)

        # 将特征拼接成一个张量
        gallery_features = torch.cat(gallery_features, dim=0)

        # 计算查询图片与验证集中所有图片的余弦相似度
        similarity = torch.nn.functional.cosine_similarity(query_feature, gallery_features)

        # 获取相似度最高的 k 张图片的索引
        top_k_indices = torch.topk(similarity, k=k).indices

        # 根据索引获取对应的图片路径
        top_k_paths = [gallery_paths[idx] for idx in top_k_indices]

        return top_k_paths

# 添加新的 API 端点
@app.post("/infer_top_k")
async def infer_top_k(request: ImageRequest, k: int = 10):
    """
    输入一张行人图片路径，返回模型识别到的前 k 张图片路径。
    """
    try:
        # 确保请求中的 image_path 存在
        if not path.exists(request.image_path):
            return {"error": f"Image path {request.image_path} does not exist."}

        # 调用 infer_top_k 方法
        top_k_paths = par_model.infer_top_k(request.image_path, k=k)
        return {"top_k_paths": top_k_paths}
    except Exception as e:
        return {"error": str(e)}