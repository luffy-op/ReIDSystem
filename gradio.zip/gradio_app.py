import gradio as gr
import requests

ATTRIBUTES = [
        "Hat", "Glasses", 
        "ShortSleeve", "LongSleeve", "UpperStride", "UpperLogo", "UpperPlaid", "UpperSplice", 
        "LowerStripe", "LowerPattern", "LongCoat", "Trousers", "Shorts", "Skirt&Dress", 
        "boots", 
        "HandBag", "ShoulderBag", "Backpack", "HoldObjectsInFront", 
        "AgeOver60", "Age18-60", "AgeLess18", 
        "Female", 
        "Front", "Side", "Back"
    ]

def greet(name, intensity):
    return "Hello, " + name + "!" * int(intensity)

# 调用FastAPI：行人属性识别
def par_pred(image_path):
    response = requests.post("http://127.0.0.1:5001/predict_par", json={"image_path": image_path})
    return response.json()["present_attributes"], response.json()["predictions"] if response.status_code == 200 else "Error"

# 调用FastAPI：行人重识别
def reid_pred(image_path):
    response = requests.post("http://127.0.0.1:5002/predict_reid", json={"image_path": image_path})
    return response.json()["predictions"] if response.status_code == 200 else "Error"

# 调用FastAPI：文本到图像行人重识别
def tireid_pred(text):
    response = requests.post("http://127.0.0.1:5003/predict_tireid", json={"text": text})
    return response.json()["predictions"] if response.status_code == 200 else "Error"

# ======== 4. Gradio 界面 ========
with gr.Blocks(css=".gradio-container { font-family: Arial, sans-serif; }") as demo:
    with gr.Tab("行人属性识别"):
        # 标题
        gr.Markdown("## 🏃‍♂️ 行人属性识别")
        gr.Markdown("通过上传图像，系统将识别行人的属性。")

        # 输入
        with gr.Row():
            image_input = gr.Image(type="filepath", label="上传图像", elem_id="image-input")
        
        # 示例数据
        examples = f'./example_par'
        
        # 添加图像示例
        gr.Examples(
            examples=examples,
            inputs=image_input,
            label="示例图像",
            elem_id="examples"
        )
        
        # 分隔线
        gr.Markdown("---")
        
        # 事件绑定
        submit_button = gr.Button("开始预测", elem_id="predict-button")

        # 输出
        with gr.Row():
            output_checkbox = gr.CheckboxGroup(ATTRIBUTES, label="检测到的属性", elem_id="attributes-output")
            output_text = gr.JSON(label="属性概率", elem_id="probabilities-output")
        
        submit_button.click(fn=par_pred, inputs=image_input, outputs=[output_checkbox, output_text])
    
    with gr.Tab("属性辅助的行人重识别"):
        # 标题
        gr.Markdown("## 🏃‍♂️ 属性辅助的行人重识别")
        gr.Markdown("通过上传图像，系统将根据属性辅助进行行人重识别。")
        
        # 输入
        with gr.Row():
            image_input = gr.Image(type="filepath", label="上传图像", elem_id="image-input-reid")
        
        # 示例数据
        examples = f'./example_reid'
        
        # 添加图像示例
        gr.Examples(
            examples=examples,
            inputs=image_input,
            label="示例图像",
            elem_id="examples-reid"
        )
        
        # 分隔线
        gr.Markdown("---")
        
        # 事件绑定
        submit_button = gr.Button("开始预测", elem_id="predict-button-reid")

        # 输出
        gallery = gr.Gallery(label="生成的图像", show_label=False, elem_id="gallery-reid", columns=[5], rows=[1], object_fit="contain", height="auto")

        submit_button.click(fn=reid_pred, inputs=image_input, outputs=gallery)
    
    with gr.Tab("文本到图像的行人重识别"):
        # 标题
        gr.Markdown("## 🏃‍♂️ 文本到图像的行人重识别")
        gr.Markdown("通过输入文本描述，系统将生成对应的行人图像。")

        # 输入
        with gr.Row():
            text_input = gr.Textbox(label="输入文本", placeholder="请输入对行人的文本描述", elem_id="text-input")
        
        # 示例数据
        # "A woman wearing a black shirt, a light blue jean jacket, a pair of brown pants and a wrist watch.",
        # "This woman is wearing silver headphones and glasses wiht a dark shirt and jeans with shoes that have a big white heel and has a pink backpack slung over her right shoulder."
        examples = [
            "A man wearing a blue and white stripe tank top, a pair of green pants and a pair of pink shoes",
            "A person is carrying a black shoulder bag over the right shoulder while wearing a white t-shirt and slender, black pants while carrying an upright, dark object in the right hand",
            "The woman has a black and white purse that is over her shoulder, she is smiling",
            "Male with black hair is wearing eyeglasses and a long sleeved shirt with dark denim pants and dark shoes"
        ]
        gr.Examples(
            examples=examples,
            inputs=text_input,
            label="示例行人描述",
            elem_id="examples-tireid"
        )

        # 分隔线
        gr.Markdown("---")

        # 事件绑定
        submit_button = gr.Button("开始预测", elem_id="predict-button-tireid")

        # 输出
        gallery = gr.Gallery(label="生成的图像", show_label=False, elem_id="gallery-tireid", columns=[5], rows=[1], object_fit="contain", height="auto")

        submit_button.click(fn=tireid_pred, inputs=text_input, outputs=gallery)

# 启动服务
demo.launch(server_name="0.0.0.0", server_port=80)